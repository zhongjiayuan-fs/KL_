

clc;
clear;
close all;
%%


fpi=fopen('LUSC_normal.txt');
hline = textscan(fpi, '%s', 1, 'delimiter', '\n');
field=textscan(hline{1}{1},'%s');
clear format;
format='%s';
% format=[format,' %s'];
for i=2:11
    format=[format,' %f'];
end
lines =textscan(fpi, format,1000000,'delimiter', '\t');
pipi=lines{1};
pprofile = [];
for i = 2 :11
    pprofile = [pprofile, lines{i}];
end
fclose(fpi);

fpi=fopen('LUSC_tumor.txt');
hline_patient_IDs = textscan(fpi, '%s', 1, 'delimiter', '\n');
hline = textscan(fpi, '%s', 1, 'delimiter', '\n');
field=textscan(hline{1}{1},'%s');
clear format;
format='%s';
% format=[format,' %s'];
for i=2:179
    format=[format,' %f'];
end
lines =textscan(fpi, format,1000000,'delimiter', '\t');
mipi=lines{1};
mprofile = [];
for i = 2 :179
    mprofile = [mprofile, lines{i}];
end
fclose(fpi);


psize=size(pprofile);
tempcontrol=pprofile;
tempcase=zeros(psize(1),7,71);
patients_num=[28,70,13,26,24,14,3];

tempcase(:,1,1:patients_num(1))=mprofile(:,1:28);    % Stage IA    
tempcase(:,2,1:patients_num(2))=mprofile(:,29:98);   % Stage IB
tempcase(:,3,1:patients_num(3))=mprofile(:,99:111);  % Stage IIA
tempcase(:,4,1:patients_num(4))=mprofile(:,112:137); % Stage IIB
tempcase(:,5,1:patients_num(5))=mprofile(:,138:161); % Stage IIIA
tempcase(:,6,1:patients_num(6))=mprofile(:,162:175); % Stage IIIB
tempcase(:,7,1:patients_num(7))=mprofile(:,176:178); % Stage IV
psize=size(tempcase);



%%
reference_num=10;
stage_num=7;
for t=1:stage_num
    for s=1:patients_num(t)
        for i=1:psize(1)
             mu=mean(tempcontrol(i,1:reference_num));
             sigma=std(tempcontrol(i,1:reference_num));
             tumor(i,t,s)= normpdf(reshape(tempcase(i,t,s),1,1),mu,sigma);
             pvalue(i,:)=normpdf(tempcontrol(i,1:reference_num),mu,sigma);
             tumor_cdf(i,t,s)=normcdf(reshape(tempcase(i,t,s),1,1),mu,sigma);
             if tumor_cdf(i,t,s)<(normcdf(mu-4*sigma,mu,sigma))
                 tumor_cdf(i,t,s)=1-tumor_cdf(i,t,s);
             end
             normal_cdf(i,1:reference_num)=normcdf(tempcontrol(i,1:reference_num),mu,sigma);
        end
       
        [tmp_com_idx,index]=sort(tumor(:,t,s));
        for count=1:3000
            tumor_cdf_num(count,t,s)=tumor_cdf(index(count),t,s);
            normal_cdf_num(count,t,s)=mean(normal_cdf(index(count),1:reference_num));
        end
    end
end


for t=1:stage_num
    for s=1:patients_num(t)
        normal_cumulative_area=normal_cdf_num(:,t,s);
        P=normal_cumulative_area(normal_cumulative_area>0);
        %P=P/sum(P);
        tumor_cumulative_area=tumor_cdf_num(:,t,s);
        Q= tumor_cumulative_area(tumor_cumulative_area>0);
        %Q=Q/sum(Q);
        kld(t,s)=0.5*(sum(P.* log(P./Q))+sum(Q .* log(Q./P)));
       
    end
end


stage_kld=zeros(1,stage_num);
for l=1:stage_num
    for s=1:patients_num(l)
        stage_kld(l)=stage_kld(l)+kld(l,s);
    end
    stage_kld(l)=stage_kld(l)/patients_num(l);
end


t=[1 2 3,4,5,6,7];
plot(t,stage_kld,'r','LineWidth',3);
set(gca,'XTick',1:7);
B={'IA' 'IB' 'IIA' 'IIB' 'IIIA' 'IIIB' 'IV'};
set(gca,'XTickLabel',B);
xlabel('Stages');
ylabel('sKLD');
title('Average sKLD for LUSC ');


















































































